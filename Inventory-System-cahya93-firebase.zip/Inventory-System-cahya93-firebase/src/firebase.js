import firebase from "firabase";

var firebaseConfig = {
  apiKey: "AIzaSyDDA5cQEIWJ3BaeCmiYpQatN6l-0YmRg3Y",
  authDomain: "react-database-b9c30.firebaseapp.com",
  databaseURL: "https://react-database-b9c30-default-rtdb.firebaseio.com",
  projectId: "react-database-b9c30",
  storageBucket: "react-database-b9c30.appspot.com",
  messagingSenderId: "667387506683",
  appId: "1:667387506683:web:117f6773f4344af9d0255e",
  measurementId: "G-2YCZ9J4JRH",
};
export default firebase.initializeApp(firebaseConfig);
