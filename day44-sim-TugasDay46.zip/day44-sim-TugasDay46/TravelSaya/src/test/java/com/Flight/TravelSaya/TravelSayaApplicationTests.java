//package com.Flight.TravelSaya;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.boot.test.context.SpringBootTest;
//
//@SpringBootTest
//class TravelSayaApplicationTests {
//
//	@Test
//	void contextLoads() {
//	}
//
//}
