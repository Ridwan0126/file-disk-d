import Dosen from "./dosen";
import Jurusan from "./jurusan";
import Mahasiswa from "./mahasiswa";
import MasterSKS from './sks'

export {MasterSKS, Mahasiswa}
export { Dosen, Jurusan };

