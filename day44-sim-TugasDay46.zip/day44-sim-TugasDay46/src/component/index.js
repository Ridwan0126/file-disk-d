
import TabelJurusan from "./table-jurusan";
import TabelDosen from "./table-dosen";
import Input from "./input";
import TableMahasiswa from "./table-mahasiswa";
import FormHeader from "./formHeader";
import Form from "./form";
import FormButton from "./formButton";
import FormInput from "./formInput";
import Table from "./table";
import Dialog from "./dialog";
import TabelSks from "./tabel-sks";

export {TableMahasiswa, Form, FormInput, FormButton, FormHeader, Input, Table, Dialog, TabelSks,  TabelJurusan, TabelDosen  }



