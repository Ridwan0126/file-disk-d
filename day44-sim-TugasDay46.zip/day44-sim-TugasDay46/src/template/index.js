import Body from "./body";
import Header from "./header";
import Nav from "./navigation";

export {Body, Nav, Header}