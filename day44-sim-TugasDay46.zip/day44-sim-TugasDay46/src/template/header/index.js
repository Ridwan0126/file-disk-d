import React, { Component } from 'react'

class Header extends Component {
    constructor(props) {
        super(props);
        this.state = {  };
    }
    render() {
        return (
            <><h1>Sistem Informasi Mahasiswa Universitas WIBU cabang Babelan</h1></>
        );
    }
}

export default Header;