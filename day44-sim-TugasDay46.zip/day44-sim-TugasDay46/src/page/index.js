import RegisterMahasiswaPage from "./register-mhs-page";
import ListDosen from "./list-dosen-page";
import ListJurusan from "./list-jurusan-page";
import ListPenerimaanPage from "./list-penerimaan-page";
import Login from "./login-page";
import SignUp from "./sign-up-page";
import ListUser from "./list-user-page"
import ListMahasiswa from "./list-mahasiswa-page";
import ListSKS from "./list-sks-page";
import DetailProfile from "./detail-profile-page";


export {ListMahasiswa,RegisterMahasiswaPage, ListPenerimaanPage, ListSKS, DetailProfile, ListDosen, ListJurusan, Login, SignUp, ListUser}



